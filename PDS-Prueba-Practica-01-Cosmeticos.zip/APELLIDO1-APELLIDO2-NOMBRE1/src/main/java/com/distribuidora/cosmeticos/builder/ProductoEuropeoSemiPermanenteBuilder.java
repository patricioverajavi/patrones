package com.distribuidora.cosmeticos.builder;

import com.distribuidora.cosmeticos.modelo.ProductoEuropeoSemiPermanente;

import java.time.LocalDate;

/** Builder concreto: arma un ProductoEuropeoSemiPermanente paso a paso. */
public class ProductoEuropeoSemiPermanenteBuilder implements CosmeticoBuilder<ProductoEuropeoSemiPermanente> {

    private String nombre;
    private double precio;
    private LocalDate fechaCaducidad;
    private String numeroLote;
    private LocalDate fechaFabricacion;
    private String paisOrigen;
    private String normaFabricacion;
    private String tiempoVidaUtil;

    public ProductoEuropeoSemiPermanenteBuilder setNombre(String nombre) {
        this.nombre = nombre;
        return this;
    }

    public ProductoEuropeoSemiPermanenteBuilder setPrecio(double precio) {
        this.precio = precio;
        return this;
    }

    public ProductoEuropeoSemiPermanenteBuilder setFechaCaducidad(LocalDate fechaCaducidad) {
        this.fechaCaducidad = fechaCaducidad;
        return this;
    }

    public ProductoEuropeoSemiPermanenteBuilder setNumeroLote(String numeroLote) {
        this.numeroLote = numeroLote;
        return this;
    }

    public ProductoEuropeoSemiPermanenteBuilder setFechaFabricacion(LocalDate fechaFabricacion) {
        this.fechaFabricacion = fechaFabricacion;
        return this;
    }

    public ProductoEuropeoSemiPermanenteBuilder setPaisOrigen(String paisOrigen) {
        this.paisOrigen = paisOrigen;
        return this;
    }

    public ProductoEuropeoSemiPermanenteBuilder setNormaFabricacion(String normaFabricacion) {
        this.normaFabricacion = normaFabricacion;
        return this;
    }

    public ProductoEuropeoSemiPermanenteBuilder setTiempoVidaUtil(String tiempoVidaUtil) {
        this.tiempoVidaUtil = tiempoVidaUtil;
        return this;
    }

    @Override
    public ProductoEuropeoSemiPermanente build() {
        return new ProductoEuropeoSemiPermanente(nombre, precio, fechaCaducidad, numeroLote,
                fechaFabricacion, paisOrigen, normaFabricacion, tiempoVidaUtil);
    }
}
