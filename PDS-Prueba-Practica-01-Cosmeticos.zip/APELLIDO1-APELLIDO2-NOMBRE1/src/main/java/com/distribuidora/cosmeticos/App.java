package com.distribuidora.cosmeticos;

import com.distribuidora.cosmeticos.composite.ItemFacturable;
import com.distribuidora.cosmeticos.composite.Paquete;
import com.distribuidora.cosmeticos.factory.FactoryProductoAmericano;
import com.distribuidora.cosmeticos.factory.FactoryProductoAsiatico;
import com.distribuidora.cosmeticos.factory.FactoryProductoEuropeo;
import com.distribuidora.cosmeticos.factory.ProductoFactory;
import com.distribuidora.cosmeticos.factura.Factura;
import com.distribuidora.cosmeticos.modelo.Cosmetico;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

/**
 * Clase de arranque: genera una compra de ejemplo usando los 4 patrones
 * (Factory, Builder, Composite, Strategy) y muestra el valor a pagar.
 */
public class App {

    public static void main(String[] args) {

        // ---------- 1. FACTORY + BUILDER: creacion de productos ----------
        ProductoFactory factoryEuropeo = new FactoryProductoEuropeo();
        ProductoFactory factoryAsiatico = new FactoryProductoAsiatico();
        ProductoFactory factoryAmericano = new FactoryProductoAmericano();

        // Producto europeo permanente
        Map<String, Object> datosEsmalte = new HashMap<>();
        datosEsmalte.put("nombre", "Esmalte Permanente Rouge");
        datosEsmalte.put("precio", 8.50);
        datosEsmalte.put("fechaCaducidad", LocalDate.of(2027, 6, 30));
        datosEsmalte.put("numeroLote", "EU-PERM-001");
        datosEsmalte.put("fechaFabricacion", LocalDate.of(2025, 1, 15));
        datosEsmalte.put("paisOrigen", "Francia");
        datosEsmalte.put("normaFabricacion", "1223/2009");
        datosEsmalte.put("composicion", "Resina acrilica + pigmentos");
        datosEsmalte.put("durabilidad", "3 semanas");
        datosEsmalte.put("riesgo", "Bajo - uso topico");
        Cosmetico esmaltePermanente = factoryEuropeo.crearProducto("PERMANENTE", datosEsmalte);

        // Producto europeo semipermanente
        Map<String, Object> datosLabial = new HashMap<>();
        datosLabial.put("nombre", "Labial SemiPermanente Rose");
        datosLabial.put("precio", 6.00);
        datosLabial.put("fechaCaducidad", LocalDate.of(2027, 3, 1));
        datosLabial.put("numeroLote", "EU-SEMI-002");
        datosLabial.put("fechaFabricacion", LocalDate.of(2025, 2, 10));
        datosLabial.put("paisOrigen", "Italia");
        datosLabial.put("normaFabricacion", "1223/2009");
        datosLabial.put("tiempoVidaUtil", "12 meses despues de abierto");
        Cosmetico labialSemiPermanente = factoryEuropeo.crearProducto("SEMIPERMANENTE", datosLabial);

        // Producto asiatico - rutina facial
        Map<String, Object> datosSerum = new HashMap<>();
        datosSerum.put("nombre", "Serum Hidratante Glass Skin");
        datosSerum.put("precio", 12.00);
        datosSerum.put("fechaCaducidad", LocalDate.of(2027, 8, 20));
        datosSerum.put("numeroLote", "AS-RUT-010");
        datosSerum.put("fechaFabricacion", LocalDate.of(2025, 4, 5));
        datosSerum.put("tipoPiel", "Mixta");
        datosSerum.put("paisOrigen", "Corea del Sur");
        datosSerum.put("ordenEnRutina", 3);
        Cosmetico serumRutina = factoryAsiatico.crearProducto("RUTINA_FACIAL", datosSerum);

        // Producto asiatico - cosmetica (maquillaje)
        Map<String, Object> datosBase = new HashMap<>();
        datosBase.put("nombre", "Base Liquida Cushion");
        datosBase.put("precio", 15.00);
        datosBase.put("fechaCaducidad", LocalDate.of(2027, 9, 10));
        datosBase.put("numeroLote", "AS-COS-021");
        datosBase.put("fechaFabricacion", LocalDate.of(2025, 5, 12));
        datosBase.put("tipoPiel", "Grasa");
        datosBase.put("paisOrigen", "Japon");
        datosBase.put("acabado", "Mate");
        Cosmetico baseCosmetica = factoryAsiatico.crearProducto("COSMETICA", datosBase);

        // Producto americano
        Map<String, Object> datosProtector = new HashMap<>();
        datosProtector.put("nombre", "Protector Solar FPS 50");
        datosProtector.put("precio", 18.00);
        datosProtector.put("fechaCaducidad", LocalDate.of(2027, 12, 1));
        datosProtector.put("numeroLote", "US-AM-030");
        datosProtector.put("fechaFabricacion", LocalDate.of(2025, 3, 20));
        datosProtector.put("paisOrigen", "Estados Unidos");
        datosProtector.put("codigoOrganismoSupervision", "FDA-NDC-12345");
        datosProtector.put("advertencias", "Evitar contacto con los ojos");
        Cosmetico protectorAmericano = factoryAmericano.crearProducto("AMERICANO", datosProtector);

        // ---------- 2. COMPOSITE: armar un paquete regalo ----------
        Paquete paqueteRegalo = new Paquete("Kit Belleza Premium");
        paqueteRegalo.agregarItem(labialSemiPermanente);
        paqueteRegalo.agregarItem(serumRutina);
        paqueteRegalo.agregarItem(baseCosmetica);

        // ---------- 3. STRATEGY (aplicada dentro de Factura): generar la compra ----------
        Factura factura = new Factura();
        factura.agregarItem(esmaltePermanente, 15);      // > 12 unidades -> 25%
        factura.agregarItem(protectorAmericano, 4);       // <= 12 unidades -> 3%
        factura.agregarItem(paqueteRegalo, 2);             // paquete -> 10%

        ItemFacturable itemImpreso = esmaltePermanente; // referencia solo para dejar claro que es ItemFacturable
        System.out.println("Item de referencia: " + itemImpreso.getNombre());

        factura.imprimirFactura();
    }
}
