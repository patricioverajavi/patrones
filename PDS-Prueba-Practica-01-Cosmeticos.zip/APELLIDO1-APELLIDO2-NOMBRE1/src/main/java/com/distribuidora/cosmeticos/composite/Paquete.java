package com.distribuidora.cosmeticos.composite;

import java.util.ArrayList;
import java.util.List;

/**
 * PATRON COMPOSITE - Compuesto
 * Representa un "paquete regalo" formado por varios productos (u otros
 * paquetes). Se factura como un unico ItemFacturable cuyo precio unitario
 * es la suma de sus componentes, lo que permite aplicarle la Strategy de
 * descuento especial de paquete (10%).
 */
public class Paquete implements ItemFacturable {

    private final String nombre;
    private final List<ItemFacturable> items = new ArrayList<>();

    public Paquete(String nombre) {
        this.nombre = nombre;
    }

    public void agregarItem(ItemFacturable item) {
        items.add(item);
    }

    public void removerItem(ItemFacturable item) {
        items.remove(item);
    }

    public List<ItemFacturable> getItems() {
        return items;
    }

    @Override
    public String getNombre() {
        return nombre;
    }

    @Override
    public double getPrecioUnitario() {
        double total = 0.0;
        for (ItemFacturable item : items) {
            total += item.getPrecioUnitario();
        }
        return total;
    }

    @Override
    public boolean esPaquete() {
        return true;
    }

    @Override
    public void mostrarDetalle() {
        System.out.println("Paquete regalo: " + nombre);
        for (ItemFacturable item : items) {
            System.out.print("   - ");
            item.mostrarDetalle();
        }
    }
}
