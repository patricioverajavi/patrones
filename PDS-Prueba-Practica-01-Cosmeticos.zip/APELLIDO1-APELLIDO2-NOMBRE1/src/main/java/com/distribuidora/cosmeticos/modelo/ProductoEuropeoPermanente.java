package com.distribuidora.cosmeticos.modelo;

import java.time.LocalDate;

/** Cosmetico europeo permanente: composicion, durabilidad y riesgo. */
public class ProductoEuropeoPermanente extends ProductoEuropeo {

    private final String composicion;
    private final String durabilidad;
    private final String riesgo;

    public ProductoEuropeoPermanente(String nombre, double precio,
                                      LocalDate fechaCaducidad, String numeroLote,
                                      LocalDate fechaFabricacion, String paisOrigen,
                                      String normaFabricacion, String composicion,
                                      String durabilidad, String riesgo) {
        super(nombre, precio, "Europeo - Permanente", fechaCaducidad, numeroLote,
                fechaFabricacion, paisOrigen, normaFabricacion);
        this.composicion = composicion;
        this.durabilidad = durabilidad;
        this.riesgo = riesgo;
    }

    @Override
    public String getInformacionEspecifica() {
        return String.format(
                "Fab: %s | Origen: %s | Norma: %s | Composicion: %s | Durabilidad: %s | Riesgo: %s",
                fechaFabricacion, paisOrigen, normaFabricacion, composicion, durabilidad, riesgo);
    }
}
