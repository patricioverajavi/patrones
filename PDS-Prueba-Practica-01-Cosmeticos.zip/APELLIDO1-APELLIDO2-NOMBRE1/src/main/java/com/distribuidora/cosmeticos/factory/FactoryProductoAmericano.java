package com.distribuidora.cosmeticos.factory;

import com.distribuidora.cosmeticos.builder.ProductoAmericanoBuilder;
import com.distribuidora.cosmeticos.modelo.Cosmetico;

import java.time.LocalDate;
import java.util.Map;

/**
 * Fabrica concreta de productos americanos. No tiene subtipos, por lo que
 * el parametro "subtipo" se ignora, pero se mantiene por respetar el
 * contrato comun ProductoFactory.
 */
public class FactoryProductoAmericano implements ProductoFactory {

    @Override
    public Cosmetico crearProducto(String subtipo, Map<String, Object> a) {
        return new ProductoAmericanoBuilder()
                .setNombre((String) a.get("nombre"))
                .setPrecio((Double) a.get("precio"))
                .setFechaCaducidad((LocalDate) a.get("fechaCaducidad"))
                .setNumeroLote((String) a.get("numeroLote"))
                .setFechaFabricacion((LocalDate) a.get("fechaFabricacion"))
                .setPaisOrigen((String) a.get("paisOrigen"))
                .setCodigoOrganismoSupervision((String) a.get("codigoOrganismoSupervision"))
                .setAdvertencias((String) a.get("advertencias"))
                .build();
    }
}
