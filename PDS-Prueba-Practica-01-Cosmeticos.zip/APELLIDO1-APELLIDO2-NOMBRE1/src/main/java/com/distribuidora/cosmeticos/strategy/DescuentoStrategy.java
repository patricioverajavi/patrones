package com.distribuidora.cosmeticos.strategy;

/**
 * PATRON STRATEGY
 * Encapsula el algoritmo de calculo de descuento para poder intercambiarlo
 * en tiempo de ejecucion segun la regla de negocio que aplique a la linea
 * de factura (por cantidad, por paquete, etc.), sin usar condicionales
 * dispersos por todo el codigo de facturacion.
 */
public interface DescuentoStrategy {

    /** Calcula el monto de descuento (no el porcentaje) sobre un subtotal. */
    double calcularDescuento(double subtotal);

    String getDescripcion();
}
