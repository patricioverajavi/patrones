package com.distribuidora.cosmeticos.composite;

/**
 * PATRON COMPOSITE - Componente
 * Interfaz comun que permite tratar de la misma forma a un producto individual
 * (hoja) y a un paquete de productos (compuesto) dentro de la facturacion.
 */
public interface ItemFacturable {

    String getNombre();

    /**
     * Precio unitario del item. En un producto simple es su precio de venta.
     * En un paquete (Composite) es la suma de los precios de sus componentes.
     */
    double getPrecioUnitario();

    /**
     * Indica si el item corresponde a un paquete promocional (compuesto),
     * usado por la Strategy para decidir el tipo de descuento aplicable.
     */
    boolean esPaquete();

    void mostrarDetalle();
}
