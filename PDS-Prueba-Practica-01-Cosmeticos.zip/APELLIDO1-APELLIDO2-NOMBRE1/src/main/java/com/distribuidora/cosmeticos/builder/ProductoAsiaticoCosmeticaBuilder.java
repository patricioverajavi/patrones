package com.distribuidora.cosmeticos.builder;

import com.distribuidora.cosmeticos.modelo.ProductoAsiaticoCosmetica;

import java.time.LocalDate;

/** Builder concreto: arma un ProductoAsiaticoCosmetica paso a paso. */
public class ProductoAsiaticoCosmeticaBuilder implements CosmeticoBuilder<ProductoAsiaticoCosmetica> {

    private String nombre;
    private double precio;
    private LocalDate fechaCaducidad;
    private String numeroLote;
    private LocalDate fechaFabricacion;
    private String tipoPiel;
    private String paisOrigen;
    private String acabado;

    public ProductoAsiaticoCosmeticaBuilder setNombre(String nombre) {
        this.nombre = nombre;
        return this;
    }

    public ProductoAsiaticoCosmeticaBuilder setPrecio(double precio) {
        this.precio = precio;
        return this;
    }

    public ProductoAsiaticoCosmeticaBuilder setFechaCaducidad(LocalDate fechaCaducidad) {
        this.fechaCaducidad = fechaCaducidad;
        return this;
    }

    public ProductoAsiaticoCosmeticaBuilder setNumeroLote(String numeroLote) {
        this.numeroLote = numeroLote;
        return this;
    }

    public ProductoAsiaticoCosmeticaBuilder setFechaFabricacion(LocalDate fechaFabricacion) {
        this.fechaFabricacion = fechaFabricacion;
        return this;
    }

    public ProductoAsiaticoCosmeticaBuilder setTipoPiel(String tipoPiel) {
        this.tipoPiel = tipoPiel;
        return this;
    }

    public ProductoAsiaticoCosmeticaBuilder setPaisOrigen(String paisOrigen) {
        this.paisOrigen = paisOrigen;
        return this;
    }

    public ProductoAsiaticoCosmeticaBuilder setAcabado(String acabado) {
        this.acabado = acabado;
        return this;
    }

    @Override
    public ProductoAsiaticoCosmetica build() {
        return new ProductoAsiaticoCosmetica(nombre, precio, fechaCaducidad, numeroLote,
                fechaFabricacion, tipoPiel, paisOrigen, acabado);
    }
}
