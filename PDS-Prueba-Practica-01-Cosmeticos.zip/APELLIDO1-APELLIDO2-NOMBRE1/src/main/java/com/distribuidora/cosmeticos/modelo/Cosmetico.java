package com.distribuidora.cosmeticos.modelo;

import com.distribuidora.cosmeticos.composite.ItemFacturable;

import java.time.LocalDate;

/**
 * Clase base para todos los cosmeticos de la distribuidora.
 * Contiene la informacion compartida por los tres tipos de producto:
 * nombre, precio, tipo, fecha de caducidad y numero de lote.
 *
 * Ademas implementa ItemFacturable para poder participar como HOJA
 * dentro del patron COMPOSITE (junto con la clase Paquete).
 */
public abstract class Cosmetico implements ItemFacturable {

    protected String nombre;
    protected double precio;
    protected String tipo;
    protected LocalDate fechaCaducidad;
    protected String numeroLote;

    protected Cosmetico(String nombre, double precio, String tipo,
                         LocalDate fechaCaducidad, String numeroLote) {
        this.nombre = nombre;
        this.precio = precio;
        this.tipo = tipo;
        this.fechaCaducidad = fechaCaducidad;
        this.numeroLote = numeroLote;
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public double getPrecioUnitario() {
        return precio;
    }

    public double getPrecio() {
        return precio;
    }

    public String getTipo() {
        return tipo;
    }

    public LocalDate getFechaCaducidad() {
        return fechaCaducidad;
    }

    public String getNumeroLote() {
        return numeroLote;
    }

    @Override
    public boolean esPaquete() {
        return false;
    }

    /** Cada subtipo concreto describe su informacion especifica. */
    public abstract String getInformacionEspecifica();

    @Override
    public void mostrarDetalle() {
        System.out.printf("%s | Precio: $%.2f | Tipo: %s | Caduca: %s | Lote: %s%n",
                nombre, precio, tipo, fechaCaducidad, numeroLote);
        System.out.println("   " + getInformacionEspecifica());
    }
}
