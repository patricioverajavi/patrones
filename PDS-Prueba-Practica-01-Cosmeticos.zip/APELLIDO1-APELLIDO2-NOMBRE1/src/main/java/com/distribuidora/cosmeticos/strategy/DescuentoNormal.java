package com.distribuidora.cosmeticos.strategy;

/** Descuento por defecto cuando la cantidad comprada no supera la docena (3%). */
public class DescuentoNormal implements DescuentoStrategy {

    private static final double PORCENTAJE = 0.03;

    @Override
    public double calcularDescuento(double subtotal) {
        return subtotal * PORCENTAJE;
    }

    @Override
    public String getDescripcion() {
        return "Descuento normal (3%)";
    }
}
