package com.distribuidora.cosmeticos.factory;

import com.distribuidora.cosmeticos.builder.ProductoAsiaticoCosmeticaBuilder;
import com.distribuidora.cosmeticos.builder.ProductoAsiaticoRutinaFacialBuilder;
import com.distribuidora.cosmeticos.modelo.Cosmetico;

import java.time.LocalDate;
import java.util.Map;

/** Fabrica concreta de productos asiaticos (Rutina Facial / Cosmetica). */
public class FactoryProductoAsiatico implements ProductoFactory {

    @Override
    public Cosmetico crearProducto(String subtipo, Map<String, Object> a) {
        switch (subtipo.toUpperCase()) {
            case "RUTINA_FACIAL":
                return new ProductoAsiaticoRutinaFacialBuilder()
                        .setNombre((String) a.get("nombre"))
                        .setPrecio((Double) a.get("precio"))
                        .setFechaCaducidad((LocalDate) a.get("fechaCaducidad"))
                        .setNumeroLote((String) a.get("numeroLote"))
                        .setFechaFabricacion((LocalDate) a.get("fechaFabricacion"))
                        .setTipoPiel((String) a.get("tipoPiel"))
                        .setPaisOrigen((String) a.get("paisOrigen"))
                        .setOrdenEnRutina((Integer) a.get("ordenEnRutina"))
                        .build();

            case "COSMETICA":
                return new ProductoAsiaticoCosmeticaBuilder()
                        .setNombre((String) a.get("nombre"))
                        .setPrecio((Double) a.get("precio"))
                        .setFechaCaducidad((LocalDate) a.get("fechaCaducidad"))
                        .setNumeroLote((String) a.get("numeroLote"))
                        .setFechaFabricacion((LocalDate) a.get("fechaFabricacion"))
                        .setTipoPiel((String) a.get("tipoPiel"))
                        .setPaisOrigen((String) a.get("paisOrigen"))
                        .setAcabado((String) a.get("acabado"))
                        .build();

            default:
                throw new IllegalArgumentException("Subtipo asiatico no reconocido: " + subtipo);
        }
    }
}
