package com.distribuidora.cosmeticos.builder;

import com.distribuidora.cosmeticos.modelo.ProductoAsiaticoRutinaFacial;

import java.time.LocalDate;

/** Builder concreto: arma un ProductoAsiaticoRutinaFacial paso a paso. */
public class ProductoAsiaticoRutinaFacialBuilder implements CosmeticoBuilder<ProductoAsiaticoRutinaFacial> {

    private String nombre;
    private double precio;
    private LocalDate fechaCaducidad;
    private String numeroLote;
    private LocalDate fechaFabricacion;
    private String tipoPiel;
    private String paisOrigen;
    private int ordenEnRutina;

    public ProductoAsiaticoRutinaFacialBuilder setNombre(String nombre) {
        this.nombre = nombre;
        return this;
    }

    public ProductoAsiaticoRutinaFacialBuilder setPrecio(double precio) {
        this.precio = precio;
        return this;
    }

    public ProductoAsiaticoRutinaFacialBuilder setFechaCaducidad(LocalDate fechaCaducidad) {
        this.fechaCaducidad = fechaCaducidad;
        return this;
    }

    public ProductoAsiaticoRutinaFacialBuilder setNumeroLote(String numeroLote) {
        this.numeroLote = numeroLote;
        return this;
    }

    public ProductoAsiaticoRutinaFacialBuilder setFechaFabricacion(LocalDate fechaFabricacion) {
        this.fechaFabricacion = fechaFabricacion;
        return this;
    }

    public ProductoAsiaticoRutinaFacialBuilder setTipoPiel(String tipoPiel) {
        this.tipoPiel = tipoPiel;
        return this;
    }

    public ProductoAsiaticoRutinaFacialBuilder setPaisOrigen(String paisOrigen) {
        this.paisOrigen = paisOrigen;
        return this;
    }

    public ProductoAsiaticoRutinaFacialBuilder setOrdenEnRutina(int ordenEnRutina) {
        this.ordenEnRutina = ordenEnRutina;
        return this;
    }

    @Override
    public ProductoAsiaticoRutinaFacial build() {
        return new ProductoAsiaticoRutinaFacial(nombre, precio, fechaCaducidad, numeroLote,
                fechaFabricacion, tipoPiel, paisOrigen, ordenEnRutina);
    }
}
