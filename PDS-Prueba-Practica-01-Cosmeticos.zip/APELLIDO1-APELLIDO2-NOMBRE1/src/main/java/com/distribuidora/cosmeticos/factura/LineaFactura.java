package com.distribuidora.cosmeticos.factura;

import com.distribuidora.cosmeticos.composite.ItemFacturable;
import com.distribuidora.cosmeticos.strategy.DescuentoStrategy;

/** Representa una linea de compra: un item (producto o paquete), su cantidad y el descuento aplicable. */
public class LineaFactura {

    private final ItemFacturable item;
    private final int cantidad;
    private final DescuentoStrategy estrategiaDescuento;

    public LineaFactura(ItemFacturable item, int cantidad, DescuentoStrategy estrategiaDescuento) {
        this.item = item;
        this.cantidad = cantidad;
        this.estrategiaDescuento = estrategiaDescuento;
    }

    public double getSubtotal() {
        return item.getPrecioUnitario() * cantidad;
    }

    public double getDescuento() {
        return estrategiaDescuento.calcularDescuento(getSubtotal());
    }

    public double getTotal() {
        return getSubtotal() - getDescuento();
    }

    public void imprimir() {
        System.out.println("--------------------------------------------------");
        item.mostrarDetalle();
        System.out.printf("Cantidad: %d | Subtotal: $%.2f%n", cantidad, getSubtotal());
        System.out.printf("%s -> -$%.2f%n", estrategiaDescuento.getDescripcion(), getDescuento());
        System.out.printf("Total linea: $%.2f%n", getTotal());
    }
}
