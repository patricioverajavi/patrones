package com.distribuidora.cosmeticos.strategy;

/** Se aplica cuando la cantidad comprada de un mismo producto supera la docena (25%). */
public class DescuentoPorDocena implements DescuentoStrategy {

    private static final double PORCENTAJE = 0.25;

    @Override
    public double calcularDescuento(double subtotal) {
        return subtotal * PORCENTAJE;
    }

    @Override
    public String getDescripcion() {
        return "Descuento por docena (25%)";
    }
}
