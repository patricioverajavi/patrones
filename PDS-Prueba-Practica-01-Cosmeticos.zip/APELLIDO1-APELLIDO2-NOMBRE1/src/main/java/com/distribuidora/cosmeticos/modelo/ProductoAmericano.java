package com.distribuidora.cosmeticos.modelo;

import java.time.LocalDate;

/**
 * Producto americano: fecha de fabricacion, pais de origen,
 * codigo del organismo de supervision (ej. FDA) y advertencias.
 */
public class ProductoAmericano extends Cosmetico {

    private final LocalDate fechaFabricacion;
    private final String paisOrigen;
    private final String codigoOrganismoSupervision;
    private final String advertencias;

    public ProductoAmericano(String nombre, double precio,
                              LocalDate fechaCaducidad, String numeroLote,
                              LocalDate fechaFabricacion, String paisOrigen,
                              String codigoOrganismoSupervision, String advertencias) {
        super(nombre, precio, "Americano", fechaCaducidad, numeroLote);
        this.fechaFabricacion = fechaFabricacion;
        this.paisOrigen = paisOrigen;
        this.codigoOrganismoSupervision = codigoOrganismoSupervision;
        this.advertencias = advertencias;
    }

    public LocalDate getFechaFabricacion() {
        return fechaFabricacion;
    }

    public String getPaisOrigen() {
        return paisOrigen;
    }

    public String getCodigoOrganismoSupervision() {
        return codigoOrganismoSupervision;
    }

    public String getAdvertencias() {
        return advertencias;
    }

    @Override
    public String getInformacionEspecifica() {
        return String.format("Fab: %s | Origen: %s | Organismo: %s | Advertencias: %s",
                fechaFabricacion, paisOrigen, codigoOrganismoSupervision, advertencias);
    }
}
