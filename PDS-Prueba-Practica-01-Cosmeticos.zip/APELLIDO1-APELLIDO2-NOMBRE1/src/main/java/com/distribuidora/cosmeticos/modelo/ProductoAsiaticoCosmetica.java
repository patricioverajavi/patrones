package com.distribuidora.cosmeticos.modelo;

import java.time.LocalDate;

/** Cosmetico asiatico de maquillaje (ej. acabado mate, brillante, etc.). */
public class ProductoAsiaticoCosmetica extends ProductoAsiatico {

    private final String acabado;

    public ProductoAsiaticoCosmetica(String nombre, double precio,
                                      LocalDate fechaCaducidad, String numeroLote,
                                      LocalDate fechaFabricacion, String tipoPiel,
                                      String paisOrigen, String acabado) {
        super(nombre, precio, "Asiatico - Cosmetica", fechaCaducidad, numeroLote,
                fechaFabricacion, tipoPiel, paisOrigen);
        this.acabado = acabado;
    }

    @Override
    public String getInformacionEspecifica() {
        return String.format("Fab: %s | Origen: %s | Tipo piel: %s | Acabado: %s",
                fechaFabricacion, paisOrigen, tipoPiel, acabado);
    }
}
