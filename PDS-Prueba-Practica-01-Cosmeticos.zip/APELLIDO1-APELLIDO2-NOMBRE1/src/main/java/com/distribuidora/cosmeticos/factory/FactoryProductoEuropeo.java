package com.distribuidora.cosmeticos.factory;

import com.distribuidora.cosmeticos.builder.ProductoEuropeoPermanenteBuilder;
import com.distribuidora.cosmeticos.builder.ProductoEuropeoSemiPermanenteBuilder;
import com.distribuidora.cosmeticos.modelo.Cosmetico;

import java.time.LocalDate;
import java.util.Map;

/** Fabrica concreta de productos europeos (Permanente / SemiPermanente). */
public class FactoryProductoEuropeo implements ProductoFactory {

    @Override
    public Cosmetico crearProducto(String subtipo, Map<String, Object> a) {
        switch (subtipo.toUpperCase()) {
            case "PERMANENTE":
                return new ProductoEuropeoPermanenteBuilder()
                        .setNombre((String) a.get("nombre"))
                        .setPrecio((Double) a.get("precio"))
                        .setFechaCaducidad((LocalDate) a.get("fechaCaducidad"))
                        .setNumeroLote((String) a.get("numeroLote"))
                        .setFechaFabricacion((LocalDate) a.get("fechaFabricacion"))
                        .setPaisOrigen((String) a.get("paisOrigen"))
                        .setNormaFabricacion((String) a.get("normaFabricacion"))
                        .setComposicion((String) a.get("composicion"))
                        .setDurabilidad((String) a.get("durabilidad"))
                        .setRiesgo((String) a.get("riesgo"))
                        .build();

            case "SEMIPERMANENTE":
                return new ProductoEuropeoSemiPermanenteBuilder()
                        .setNombre((String) a.get("nombre"))
                        .setPrecio((Double) a.get("precio"))
                        .setFechaCaducidad((LocalDate) a.get("fechaCaducidad"))
                        .setNumeroLote((String) a.get("numeroLote"))
                        .setFechaFabricacion((LocalDate) a.get("fechaFabricacion"))
                        .setPaisOrigen((String) a.get("paisOrigen"))
                        .setNormaFabricacion((String) a.get("normaFabricacion"))
                        .setTiempoVidaUtil((String) a.get("tiempoVidaUtil"))
                        .build();

            default:
                throw new IllegalArgumentException("Subtipo europeo no reconocido: " + subtipo);
        }
    }
}
