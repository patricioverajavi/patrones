package com.distribuidora.cosmeticos.strategy;

/** Descuento especial aplicado a la compra de un paquete regalo (10%). */
public class DescuentoPaquete implements DescuentoStrategy {

    private static final double PORCENTAJE = 0.10;

    @Override
    public double calcularDescuento(double subtotal) {
        return subtotal * PORCENTAJE;
    }

    @Override
    public String getDescripcion() {
        return "Descuento especial por paquete (10%)";
    }
}
