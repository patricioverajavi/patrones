package com.distribuidora.cosmeticos.builder;

import com.distribuidora.cosmeticos.modelo.ProductoAmericano;

import java.time.LocalDate;

/** Builder concreto: arma un ProductoAmericano paso a paso. */
public class ProductoAmericanoBuilder implements CosmeticoBuilder<ProductoAmericano> {

    private String nombre;
    private double precio;
    private LocalDate fechaCaducidad;
    private String numeroLote;
    private LocalDate fechaFabricacion;
    private String paisOrigen;
    private String codigoOrganismoSupervision;
    private String advertencias;

    public ProductoAmericanoBuilder setNombre(String nombre) {
        this.nombre = nombre;
        return this;
    }

    public ProductoAmericanoBuilder setPrecio(double precio) {
        this.precio = precio;
        return this;
    }

    public ProductoAmericanoBuilder setFechaCaducidad(LocalDate fechaCaducidad) {
        this.fechaCaducidad = fechaCaducidad;
        return this;
    }

    public ProductoAmericanoBuilder setNumeroLote(String numeroLote) {
        this.numeroLote = numeroLote;
        return this;
    }

    public ProductoAmericanoBuilder setFechaFabricacion(LocalDate fechaFabricacion) {
        this.fechaFabricacion = fechaFabricacion;
        return this;
    }

    public ProductoAmericanoBuilder setPaisOrigen(String paisOrigen) {
        this.paisOrigen = paisOrigen;
        return this;
    }

    public ProductoAmericanoBuilder setCodigoOrganismoSupervision(String codigoOrganismoSupervision) {
        this.codigoOrganismoSupervision = codigoOrganismoSupervision;
        return this;
    }

    public ProductoAmericanoBuilder setAdvertencias(String advertencias) {
        this.advertencias = advertencias;
        return this;
    }

    @Override
    public ProductoAmericano build() {
        return new ProductoAmericano(nombre, precio, fechaCaducidad, numeroLote,
                fechaFabricacion, paisOrigen, codigoOrganismoSupervision, advertencias);
    }
}
