package com.distribuidora.cosmeticos.modelo;

import java.time.LocalDate;

/** Cosmetico asiatico de rutina facial (ej. paso de una skincare routine). */
public class ProductoAsiaticoRutinaFacial extends ProductoAsiatico {

    private final int ordenEnRutina;

    public ProductoAsiaticoRutinaFacial(String nombre, double precio,
                                         LocalDate fechaCaducidad, String numeroLote,
                                         LocalDate fechaFabricacion, String tipoPiel,
                                         String paisOrigen, int ordenEnRutina) {
        super(nombre, precio, "Asiatico - Rutina Facial", fechaCaducidad, numeroLote,
                fechaFabricacion, tipoPiel, paisOrigen);
        this.ordenEnRutina = ordenEnRutina;
    }

    @Override
    public String getInformacionEspecifica() {
        return String.format("Fab: %s | Origen: %s | Tipo piel: %s | Paso rutina N°: %d",
                fechaFabricacion, paisOrigen, tipoPiel, ordenEnRutina);
    }
}
