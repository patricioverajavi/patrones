package com.distribuidora.cosmeticos.factory;

import com.distribuidora.cosmeticos.modelo.Cosmetico;

import java.util.Map;

/**
 * PATRON FACTORY (Factory Method)
 * Cada familia de producto (Europeo, Asiatico, Americano) tiene su propia
 * fabrica concreta. El cliente (App/Factura) no conoce las clases concretas
 * ni la forma de construirlas (eso lo resuelve el Builder internamente);
 * solo indica el subtipo y sus atributos.
 */
public interface ProductoFactory {

    /**
     * Crea un cosmetico de la familia correspondiente.
     *
     * @param subtipo   subtipo dentro de la familia (ej. "PERMANENTE",
     *                  "RUTINA_FACIAL"). Puede ignorarse si la familia
     *                  no tiene subtipos (caso Americano).
     * @param atributos mapa con los atributos necesarios para construir el
     *                  producto (nombre, precio, fechas, etc.)
     */
    Cosmetico crearProducto(String subtipo, Map<String, Object> atributos);
}
