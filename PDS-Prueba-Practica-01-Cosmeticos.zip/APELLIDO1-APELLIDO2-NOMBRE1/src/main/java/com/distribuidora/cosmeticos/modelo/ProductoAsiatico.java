package com.distribuidora.cosmeticos.modelo;

import java.time.LocalDate;

/**
 * Producto asiatico: agrega fecha de fabricacion, tipo de piel y pais de origen.
 * Se especializa en Rutina Facial y Cosmetica.
 */
public abstract class ProductoAsiatico extends Cosmetico {

    protected LocalDate fechaFabricacion;
    protected String tipoPiel;
    protected String paisOrigen;

    protected ProductoAsiatico(String nombre, double precio, String tipo,
                                LocalDate fechaCaducidad, String numeroLote,
                                LocalDate fechaFabricacion, String tipoPiel,
                                String paisOrigen) {
        super(nombre, precio, tipo, fechaCaducidad, numeroLote);
        this.fechaFabricacion = fechaFabricacion;
        this.tipoPiel = tipoPiel;
        this.paisOrigen = paisOrigen;
    }

    public LocalDate getFechaFabricacion() {
        return fechaFabricacion;
    }

    public String getTipoPiel() {
        return tipoPiel;
    }

    public String getPaisOrigen() {
        return paisOrigen;
    }
}
