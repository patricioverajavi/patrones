package com.distribuidora.cosmeticos.factura;

import com.distribuidora.cosmeticos.composite.ItemFacturable;
import com.distribuidora.cosmeticos.strategy.DescuentoNormal;
import com.distribuidora.cosmeticos.strategy.DescuentoPaquete;
import com.distribuidora.cosmeticos.strategy.DescuentoPorDocena;
import com.distribuidora.cosmeticos.strategy.DescuentoStrategy;

import java.util.ArrayList;
import java.util.List;

/**
 * Factura de compra. Por cada item agregado selecciona (Strategy) el
 * descuento que le corresponde:
 *  - Si el item es un Paquete (Composite) -> 10%
 *  - Si la cantidad de un producto individual supera la docena -> 25%
 *  - En caso contrario -> 3%
 */
public class Factura {

    private final List<LineaFactura> lineas = new ArrayList<>();

    public void agregarItem(ItemFacturable item, int cantidad) {
        DescuentoStrategy estrategia = seleccionarEstrategia(item, cantidad);
        lineas.add(new LineaFactura(item, cantidad, estrategia));
    }

    private DescuentoStrategy seleccionarEstrategia(ItemFacturable item, int cantidad) {
        if (item.esPaquete()) {
            return new DescuentoPaquete();
        }
        if (cantidad > 12) {
            return new DescuentoPorDocena();
        }
        return new DescuentoNormal();
    }

    public double getTotalAPagar() {
        double total = 0.0;
        for (LineaFactura linea : lineas) {
            total += linea.getTotal();
        }
        return total;
    }

    public void imprimirFactura() {
        System.out.println("====================================================");
        System.out.println("           FACTURA - DISTRIBUIDORA DE COSMETICOS");
        System.out.println("====================================================");
        for (LineaFactura linea : lineas) {
            linea.imprimir();
        }
        System.out.println("====================================================");
        System.out.printf("VALOR TOTAL A PAGAR: $%.2f%n", getTotalAPagar());
        System.out.println("====================================================");
    }
}
