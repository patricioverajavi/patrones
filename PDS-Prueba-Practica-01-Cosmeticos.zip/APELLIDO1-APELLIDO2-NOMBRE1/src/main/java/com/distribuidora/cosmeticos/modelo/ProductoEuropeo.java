package com.distribuidora.cosmeticos.modelo;

import java.time.LocalDate;

/**
 * Producto europeo: agrega fecha de fabricacion, pais de origen
 * y norma de fabricacion (ej. 1223/2009).
 * Se especializa en Permanente y SemiPermanente.
 */
public abstract class ProductoEuropeo extends Cosmetico {

    protected LocalDate fechaFabricacion;
    protected String paisOrigen;
    protected String normaFabricacion;

    protected ProductoEuropeo(String nombre, double precio, String tipo,
                               LocalDate fechaCaducidad, String numeroLote,
                               LocalDate fechaFabricacion, String paisOrigen,
                               String normaFabricacion) {
        super(nombre, precio, tipo, fechaCaducidad, numeroLote);
        this.fechaFabricacion = fechaFabricacion;
        this.paisOrigen = paisOrigen;
        this.normaFabricacion = normaFabricacion;
    }

    public LocalDate getFechaFabricacion() {
        return fechaFabricacion;
    }

    public String getPaisOrigen() {
        return paisOrigen;
    }

    public String getNormaFabricacion() {
        return normaFabricacion;
    }
}
