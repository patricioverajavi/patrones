package com.distribuidora.cosmeticos.builder;

import com.distribuidora.cosmeticos.modelo.ProductoEuropeoPermanente;

import java.time.LocalDate;

/** Builder concreto: arma un ProductoEuropeoPermanente paso a paso. */
public class ProductoEuropeoPermanenteBuilder implements CosmeticoBuilder<ProductoEuropeoPermanente> {

    private String nombre;
    private double precio;
    private LocalDate fechaCaducidad;
    private String numeroLote;
    private LocalDate fechaFabricacion;
    private String paisOrigen;
    private String normaFabricacion;
    private String composicion;
    private String durabilidad;
    private String riesgo;

    public ProductoEuropeoPermanenteBuilder setNombre(String nombre) {
        this.nombre = nombre;
        return this;
    }

    public ProductoEuropeoPermanenteBuilder setPrecio(double precio) {
        this.precio = precio;
        return this;
    }

    public ProductoEuropeoPermanenteBuilder setFechaCaducidad(LocalDate fechaCaducidad) {
        this.fechaCaducidad = fechaCaducidad;
        return this;
    }

    public ProductoEuropeoPermanenteBuilder setNumeroLote(String numeroLote) {
        this.numeroLote = numeroLote;
        return this;
    }

    public ProductoEuropeoPermanenteBuilder setFechaFabricacion(LocalDate fechaFabricacion) {
        this.fechaFabricacion = fechaFabricacion;
        return this;
    }

    public ProductoEuropeoPermanenteBuilder setPaisOrigen(String paisOrigen) {
        this.paisOrigen = paisOrigen;
        return this;
    }

    public ProductoEuropeoPermanenteBuilder setNormaFabricacion(String normaFabricacion) {
        this.normaFabricacion = normaFabricacion;
        return this;
    }

    public ProductoEuropeoPermanenteBuilder setComposicion(String composicion) {
        this.composicion = composicion;
        return this;
    }

    public ProductoEuropeoPermanenteBuilder setDurabilidad(String durabilidad) {
        this.durabilidad = durabilidad;
        return this;
    }

    public ProductoEuropeoPermanenteBuilder setRiesgo(String riesgo) {
        this.riesgo = riesgo;
        return this;
    }

    @Override
    public ProductoEuropeoPermanente build() {
        return new ProductoEuropeoPermanente(nombre, precio, fechaCaducidad, numeroLote,
                fechaFabricacion, paisOrigen, normaFabricacion, composicion, durabilidad, riesgo);
    }
}
