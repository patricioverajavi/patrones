package com.distribuidora.cosmeticos.builder;

/**
 * PATRON BUILDER - Interfaz comun del builder.
 * Cada tipo/subtipo de cosmetico tiene varios atributos (algunos comunes,
 * otros propios), por lo que construirlo con un constructor tradicional
 * seria pesado y propenso a errores. El Builder arma el objeto paso a
 * paso mediante metodos encadenados (fluent API) y finalmente lo entrega
 * con build().
 */
public interface CosmeticoBuilder<T> {
    T build();
}
