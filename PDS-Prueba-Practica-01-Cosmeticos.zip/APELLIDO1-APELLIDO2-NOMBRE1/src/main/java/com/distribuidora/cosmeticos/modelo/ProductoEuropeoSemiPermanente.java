package com.distribuidora.cosmeticos.modelo;

import java.time.LocalDate;

/** Cosmetico europeo semi permanente: tiempo de vida util. */
public class ProductoEuropeoSemiPermanente extends ProductoEuropeo {

    private final String tiempoVidaUtil;

    public ProductoEuropeoSemiPermanente(String nombre, double precio,
                                          LocalDate fechaCaducidad, String numeroLote,
                                          LocalDate fechaFabricacion, String paisOrigen,
                                          String normaFabricacion, String tiempoVidaUtil) {
        super(nombre, precio, "Europeo - SemiPermanente", fechaCaducidad, numeroLote,
                fechaFabricacion, paisOrigen, normaFabricacion);
        this.tiempoVidaUtil = tiempoVidaUtil;
    }

    @Override
    public String getInformacionEspecifica() {
        return String.format("Fab: %s | Origen: %s | Norma: %s | Vida util: %s",
                fechaFabricacion, paisOrigen, normaFabricacion, tiempoVidaUtil);
    }
}
