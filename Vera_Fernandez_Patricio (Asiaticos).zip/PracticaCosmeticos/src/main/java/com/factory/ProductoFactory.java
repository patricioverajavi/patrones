package com.factory;

import java.time.LocalDate;
import com.interfaz.Producto;


import com.modelo.EuropeoPermanente;
import com.modelo.EuropeoSemiPermanente;
import com.modelo.ProductoAsiatico;
import com.modelo.ProductoAmericano;

public class ProductoFactory {
    
    // 1. Productos Europeos - Permanentes
    public Producto createEuropeoPermanente(String nombre, double precio, String pais, String norma, String composicion, int durabilidad, String riesgo) {
		return null;
      /*  return new EuropeoPermanente(
            nombre, precio, "Europeos - Permanente", 
            LocalDate.now().plusYears(2), 10, 
            LocalDate.now(), pais, norma, 
            composicion, durabilidad, riesgo
        );*/
    }
    
    // 2. Productos Europeos - Semi Permanentes
    public Producto createEuropeoSemiPermanente(String nombre, double precio, String pais, String norma, String tiempoVidaUtil) {
		return null;
       /* return new EuropeoSemiPermanente(
            nombre, precio, "Europeos - Semi Permanente", 
            LocalDate.now().plusYears(1), 12, 
            LocalDate.now(), pais, norma, 
            tiempoVidaUtil
        );*/
    }
    
    // 3. Productos Asiáticos (Maneja tanto "rutina facial" como "cosmética" en el parámetro categoria)
    public Producto createAsiatico(String nombre, double precio, String pais, String tipoPiel, String categoria) {
        // Validación opcional por consistencia con el enunciado
        if (!categoria.equalsIgnoreCase("rutina facial") && !categoria.equalsIgnoreCase("cosmética")) {
            throw new IllegalArgumentException("Categoría asiática no válida. Debe ser 'rutina facial' o 'cosmética'.");
        }
      /*  return new ProductoAsiatico(
            nombre, precio, "Asiaticos", 
            LocalDate.now().plusYears(3), 20, 
            LocalDate.now(), tipoPiel, pais, categoria
        );
    }*/
		return null;
    }

    // 4. Productos Americanos
    public Producto createAmericano(String nombre, double precio, String pais, String codigoSupervision, String advertencias) {
		return null;
       /* return new ProductoAmericano(
            nombre, precio, "Americanos", 
            LocalDate.now().plusYears(2), 5, 
            LocalDate.now(), pais, codigoSupervision, advertencias
        );
    }*/
}}