package com.modelo;

public class ProductoAmericano {
	private String fechaFabricacion;
	private String paisOrigen;
	private String codigoSupervision;
	private String advertencias;
	public ProductoAmericano(String fechaFabricacion, String paisOrigen, String codigoOrgcodigoSupervisionanismo, String advertencias) {
		super();
		this.fechaFabricacion = fechaFabricacion;
		this.paisOrigen = paisOrigen;
		this.codigoSupervision = codigoSupervision;
		this.advertencias = advertencias;
	}
	
    public String getInformacion() {
        return getInformacion() + " [AMERICANO] -> Origen: " + paisOrigen + 
               " | Org. Supervisión: " + codigoSupervision + " | ADVERTENCIAS: " + advertencias;
    }

}
