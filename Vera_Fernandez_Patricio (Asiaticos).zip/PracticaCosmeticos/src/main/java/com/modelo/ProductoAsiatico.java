package com.modelo;

public class ProductoAsiatico {
	
	private String fechaFabricacion;
	private String tipoPiel;
	private String paisOrigen;
	public ProductoAsiatico(String fechaFabricacion, String tipoPiel, String paisOrigen) {
		super();
		this.fechaFabricacion = fechaFabricacion;
		this.tipoPiel = tipoPiel;
		this.paisOrigen = paisOrigen;
	}
	public String getFechaFabricacion() {
		return fechaFabricacion;
	}
	public String getTipoPiel() {
		return tipoPiel;
	}
	public String getPaisOrigen() {
		return paisOrigen;
	}

	
	
	
	
}
