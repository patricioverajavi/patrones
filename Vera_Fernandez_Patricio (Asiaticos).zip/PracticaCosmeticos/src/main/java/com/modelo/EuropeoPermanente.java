package com.modelo;

public class EuropeoPermanente extends ProductoEuropeo {
	private String composicion;
    private int durabilidad;
    private String riesgo;
	public EuropeoPermanente(String fechaFabricacion, String paisOrigen, String normaFabricacion, String composicion,
			int durabilidad, String riesgo) {
		super(fechaFabricacion, paisOrigen, normaFabricacion);
		this.composicion = composicion;
		this.durabilidad = durabilidad;
		this.riesgo = riesgo;
	}
	
    public String getInformacion() {
        return getInformacion() + " [EUROPEO PERMANENTE] -> Origen: " + getPaisOrigen() + 
               " | Norma: " + getNormaFabricacion() + " | Composición: " + composicion + 
               " | Durabilidad: " + durabilidad+ " meses | Riesgo: " + riesgo;
    }

    
}
