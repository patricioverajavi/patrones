package com.modelo;

public class EuropeoSemiPermanente extends ProductoEuropeo {
	private String vidaUtil;

	public EuropeoSemiPermanente(String fechaFabricacion, String paisOrigen, String normaFabricacion, String vidaUtil) {
		super(fechaFabricacion, paisOrigen, normaFabricacion);
		this.vidaUtil = vidaUtil;
	}

	
    public String getInformacion() {
        return getInformacion() + " [EUROPEO SEMI-PERMANENTE] -> Origen: " + getPaisOrigen() + 
               " | Norma: " + getNormaFabricacion() + " | Vida Útil: " + vidaUtil;
    }


}
