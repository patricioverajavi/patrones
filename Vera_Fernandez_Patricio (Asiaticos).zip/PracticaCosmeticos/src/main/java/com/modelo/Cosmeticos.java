package com.modelo;

import java.time.LocalDate;

import com.interfaz.Producto;

public class Cosmeticos implements Producto{
	private String nombre;
	private double precio;
	private String tipo;
	private LocalDate fechaCaducidad;
	private int numlote;
	
	public Cosmeticos(String n, double p, String tipo, LocalDate fechaCaducidad, int numlote) {
		super();
		this.nombre = n;
		this.precio = p;
		this.tipo = tipo;
		this.fechaCaducidad = fechaCaducidad;
		this.numlote = numlote;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public LocalDate getFechaCaducidad() {
		return fechaCaducidad;
	}

	public void setFechaCaducidad(LocalDate fechaCaducidad) {
		this.fechaCaducidad = fechaCaducidad;
	}

	public int getNumlote() {
		return numlote;
	}

	public void setNumlote(int numlote) {
		this.numlote = numlote;
	}

	@Override
	public String toString() {
		return "Cosmeticos [nombre=" + nombre + ", precio=" + precio + ", tipo=" + tipo + ", fechaCaducidad="
				+ fechaCaducidad + ", numlote=" + numlote + "]";
	}

	@Override
	public String getInformacion() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	
	
	
	
	

}
