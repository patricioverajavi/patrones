package com.modelo;

public class ProductoEuropeo {
	private String fechaFabricacion;
    private String paisOrigen;
    private String normaFabricacion;
	public ProductoEuropeo(String fechaFabricacion, String paisOrigen, String normaFabricacion) {
		super();
		this.fechaFabricacion = fechaFabricacion;
		this.paisOrigen = paisOrigen;
		this.normaFabricacion = normaFabricacion;
	}
	public String getFechaFabricacion() {
		return fechaFabricacion;
	}
	public String getPaisOrigen() {
		return paisOrigen;
	}
	public String getNormaFabricacion() {
		return normaFabricacion;
	}

    
   
}
