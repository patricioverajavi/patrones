package com.strategy;

import java.util.ArrayList;
import java.util.List;

import com.interfaz.Producto;

public class PaqueteRegalo implements Producto {
    private String nombre;
    private List<Producto> listaProductos = new ArrayList<>();

    public PaqueteRegalo(String nombre) {
        this.nombre = nombre;
    }

    public void añadirProducto(Producto p) {
        listaProductos.add(p);
    }

    @Override
    public String getNombre() {
        return this.nombre;
    }

    @Override
    public double getPrecio() {
          return listaProductos.stream().mapToDouble(Producto::getPrecio).sum();
    }

    @Override
    public String getInformacion() {
        return "Paquete de regalo con " + listaProductos.size() + " productos.";
    }
}