package com.strategy;

public interface Descuento {
	
	    double aplicarDescuento(double total);
	}