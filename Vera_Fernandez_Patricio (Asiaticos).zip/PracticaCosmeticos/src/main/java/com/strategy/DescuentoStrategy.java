package com.strategy;

public class DescuentoStrategy {

}
