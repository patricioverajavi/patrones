package com.interfaz;

public interface Producto {
	String getNombre();
	double getPrecio();
	String getInformacion();

}
 
