package com.builder;

public enum Tipos {
	PERMANENTES,SEMIPERMANENTES

}
