package com.composite;

import java.util.ArrayList;
import java.util.List;

import com.interfaz.Producto;

public class ProductoComposite implements Producto  {
	List<Producto> it= new ArrayList<>();
	void add(Producto p) {
		it.add(p);
		
		
	}

	@Override
	public String getNombre() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public double getPrecio() {
		return it.stream().mapToDouble(Producto::getPrecio).sum();
		
	}

	@Override
	public String getInformacion() {
		// TODO Auto-generated method stub
		return null;
	}

}
